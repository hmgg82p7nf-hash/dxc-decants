DXC Decants website
Open index.html in a browser.

Included:
- DXC logo built directly in HTML/CSS
- Decants: 3ML, 5ML, 10ML
- Current six fragrances and prices
- Real bottle image references
- Full bottle section
- Fragrance minis section
- More cologne request section
- Contact form
- Cart counter

Note: the bottle images use web-hosted image URLs so they can load when the site is online.
